function [gauss, x] = fit_gauss(x_data, y_data, mu, interval)
%FIT_GAUSS Summary of this function goes here
%   Detailed explanation goes here
    i = x_data>=(mu-interval) & x_data<=(mu+interval);
    gauss = fit(x_data(i), y_data(i), 'gauss1');
    
    figure(2);
    hold on;
    plot(x_data(i), y_data(i));
    x = linspace(min(x_data(i)),max(x_data(i)),1000);
    plot(x, gauss(x));
end

