data = importdata('h_stort_spektra.TXT', ';');
data = data.data;

lambda = data(:,1);
spektra = data(:,5);

% konvertera till vakum lambda
n = 1.000293; % brytningsindex luft
lambda = lambda*n;

% 656.5 f�r h�gsta
[gauss,x] = fit_gauss(lambda, spektra, 657, 10);
[M, I] = max(gauss(x));

% v�gl�ngden f�r den st�rsta stapeln
lambda_max = x(I)

R = (1/(1/2^2 - 1/3^2))*1/(lambda_max*1e-9)
R_teori = 1.097373156850865e7

h = 6.6261e-34;
c = 2.99792458e8;
rydberg_lambda = 1/(R_teori*(1/2^2 - 1/3^2))

% plot
figure(1);
hold on;
box on;
grid on;
plot(lambda, spektra);
xlim([min(lambda) max(750)]);
ylim([0 7e4]);
title('Emission spectra for Hydrogen', 'Interpreter', 'latex', 'FontSize', 18);
xlabel('Wavelength (nm)', 'Interpreter', 'latex', 'FontSize', 18);
ylabel('Counts', 'Interpreter', 'latex', 'FontSize', 18);
set(gca, 'XTick', 300:50:750);

